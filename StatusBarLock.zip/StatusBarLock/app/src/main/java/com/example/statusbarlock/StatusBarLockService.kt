package com.example.statusbarlock

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class StatusBarLockService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var overlay: View? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id)
        else (24 * resources.displayMetrics.density).toInt()
    }

    private fun addOverlay() {
        if (overlay != null) return
        val view = View(this)
        val screenWidth = resources.displayMetrics.widthPixels
        var swiped = false

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                swiped = false
                return true
            }

            // 雙擊 -> 鎖定螢幕
            override fun onDoubleTap(e: MotionEvent): Boolean {
                performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                return true
            }

            // 下滑：左半邊開通知欄，右半邊開快速設定
            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float
            ): Boolean {
                if (e1 == null || swiped) return false
                if (e2.y - e1.y > 40) {
                    swiped = true
                    if (e1.x > screenWidth / 2) {
                        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                    } else {
                        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                    }
                    return true
                }
                return false
            }
        })

        view.setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            statusBarHeight(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        wm.addView(view, params)
        overlay = view
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        overlay?.let { wm.removeView(it) }
        overlay = null
        super.onDestroy()
    }
}
