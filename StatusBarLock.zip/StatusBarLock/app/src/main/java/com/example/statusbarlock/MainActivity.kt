package com.example.statusbarlock

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        layout.addView(TextView(this).apply {
            text = "雙擊狀態列鎖屏"
            textSize = 24f
        })

        layout.addView(TextView(this).apply {
            text = "\n啟用步驟：\n\n" +
                "1. 點下方第一顆按鈕，進入本 App 資訊頁，右上角 ⋮ →「允許受限制的設定」（側載安裝才需要）。\n\n" +
                "2. 點第二顆按鈕，在「已安裝的應用程式」中開啟「雙擊狀態列鎖屏」。\n\n" +
                "3. 開啟 Samsung 的「設定 → 進階功能 → 動作與手勢 → 輕點兩下開啟螢幕」，即可雙擊亮屏。\n"
            textSize = 16f
        })

        layout.addView(Button(this).apply {
            text = "1. 開啟 App 資訊頁"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        layout.addView(Button(this).apply {
            text = "2. 開啟無障礙設定"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
