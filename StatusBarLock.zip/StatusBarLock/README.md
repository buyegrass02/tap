# StatusBarLock

雙擊狀態列鎖定螢幕的 Android 無障礙服務（針對 Samsung Galaxy S24 Ultra）。

## 取得 APK
1. 把整個專案推上 GitHub。
2. 到 repo 的 **Actions** 分頁，等 "Build APK" 跑完（約 3–5 分鐘）。
3. 點進該次執行，在 **Artifacts** 下載 `StatusBarLock-debug-apk`，解壓縮得到 `app-debug.apk`。

## 安裝與啟用
開啟 App，依畫面三個步驟操作即可。亮屏請使用 Samsung 內建的「輕點兩下開啟螢幕」。
